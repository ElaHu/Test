//
//  TTProject.h
//  TTProject
//
//  Created by huweihong on 2019/3/18.
//  Copyright © 2019年 huweihong. All rights reserved.
//

#import <UIKit/UIKit.h>
//! Project version number for TTProject.
FOUNDATION_EXPORT double TTProjectVersionNumber;

//! Project version string for TTProject.
FOUNDATION_EXPORT const unsigned char TTProjectVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <TTProject/PublicHeader.h>

